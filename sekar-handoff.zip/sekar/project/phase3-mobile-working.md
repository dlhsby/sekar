# Phase 3: Mobile Requirements

**Last Updated:** 2026-04-25
**Status:** ⏳ Not Started
**Framework:** React Native 0.83.4, React 19.2.4, Redux Toolkit, @react-native-mapbox-gl/maps
**Related ADRs:** [ADR-029](../../architecture/decisions/ADR-029-monitoring-v2-redis.md), [ADR-030](../../architecture/decisions/ADR-030-area-aggregate-plant-inventory.md), [ADR-031](../../architecture/decisions/ADR-031-task-typing-custom-fields.md), [ADR-033](../../architecture/decisions/ADR-033-staff-kecamatan-role.md)
**See also:** [Backend](./backend.md), [UI/UX](./ui-ux.md), [README](./README.md)

---

## Apr 24 Marker/Trail Fixes — MUST PRESERVE

Commit `c2b8e85` (Apr 24, 2026) shipped four monitoring-map stability fixes. Phase 3 extends the map without regressing these. **All new map components inherit the same patterns.**

| Fix | Pattern | Phase 3 consequence |
|-----|---------|---------------------|
| Marker bitmap redraw thrash | `tracksViewChanges={false}` + `LabelMode` enum in marker `key` (not raw `zoomLevel` float) | `ClusterMarker` re-uses the same pattern; a lint rule (ESLint custom) forbids `tracksViewChanges={true}` anywhere under `components/monitoring/` |
| `LocationTrail` bridge crash (`addViewAt`) | `requestAnimationFrame` mount guard | Reference pattern for any new GL-bridged overlay |
| Stale boundaries after tab refocus | `useFocusEffect` + `boundaryKey` forcing Polygon remount | Inherited by `AreaStatusOverlay` and `PlantOverlayLayer` |
| Bottom-sheet race on `handleMarkerPress` | Removed `animateToRegion` in favor of bottom-sheet `snapToIndex` | Cluster press handler uses the same pattern (expand cluster OR snap sheet, not both) |

`components/monitoring/LocationTrail.tsx` and `UserMarker.tsx` are **reference files** — do not modify in Phase 3. `ClusterMarker` is introduced as a **parallel** component behind a feature flag (`featureFlags.clusterMarkersV2`) so we can roll back instantly if cluster rendering regresses.

---

## New / Modified Screens

### Monitoring (sub-phase 3-5)

| File | Responsibility | Slice |
|------|----------------|-------|
| `src/screens/monitoring/MapDashboardScreen.tsx` | Host for v2 map; preserves existing Redux wiring; adds `ClusterLayer`, `AreaStatusOverlay`, `MonitoringToggleSheet` | `monitoringV2` |
| `src/components/monitoring/ClusterMarker.tsx` | Cluster bubble with count; `tracksViewChanges={false}`; key includes `{ zoomBucket, count }` | — |
| `src/components/monitoring/ClusteredUserMarkers.tsx` | Chooses `ClusterMarker` vs per-user `UserMarker` based on `zoomLevel >= cluster_zoom_threshold` | `monitoringV2` |
| `src/components/monitoring/MonitoringToggleSheet.tsx` | NB bottom-sheet: workers / plants / overdue / rayons / areas toggles | `monitoringV2.visibleLayers` |
| `src/components/monitoring/AreaStatusOverlay.tsx` | Area polygons filled by `area_plants.status` (green/yellow/red). `useFocusEffect` reload on tab return | `plants.areaStatusById` |
| `src/components/monitoring/PlantOverlayLayer.tsx` | Notable-plants markers and overdue-count badges | `plants.notableByArea` |
| `src/components/monitoring/UserMarker.tsx` | **Unchanged** — preserves Apr 24 fixes | — |
| `src/components/monitoring/LocationTrail.tsx` | **Unchanged** — `requestAnimationFrame` guard | — |

### Tasks (sub-phase 3-7)

| File | Responsibility | Slice |
|------|----------------|-------|
| `src/components/tasks/PruningTaskForm.tsx` | Dynamic form: species autocomplete (131 entries), quantity input per species, maintenance type (PC/PM/PB), partial-complete CTA | `tasks` |
| `src/components/tasks/SpeciesAutocomplete.tsx` | Autocomplete with fuzzy match over `plant_species.name_id`; caches catalog in Redux | `plants.speciesCatalog` |
| `src/screens/tasks/TaskDetailScreen.tsx` | Adds "Lanjutkan Besok" CTA that calls `/tasks/:id/resume`; shows parent/child lineage | `tasks.lineageById` |
| `src/screens/tasks/PartialCompleteSheet.tsx` | Bottom sheet for partial completion (completed_count, plant_items) | — |

### Pruning requests (sub-phase 3-10)

| File | Responsibility | Role gate | Slice |
|------|----------------|-----------|-------|
| `src/screens/pruningRequests/SubmitScreen.tsx` | Kecamatan staff submission: address, expected date, photos (3-5), GPS capture | `staff_kecamatan` | `pruningRequests` |
| `src/screens/pruningRequests/MyRequestsScreen.tsx` | List of own submissions with status chips | `staff_kecamatan` | `pruningRequests` |
| `src/screens/pruningRequests/RequestDetailScreen.tsx` | Outcome view: converted task + activities + photos | submitter, reviewer, admin | `pruningRequests` |
| `src/screens/pruningRequests/ReviewQueueScreen.tsx` | Approve / reject / convert-to-task; capacity indicator on convert | `admin_data` | `pruningRequests` |
| `src/screens/pruningRequests/ConvertToTaskSheet.tsx` | Bottom sheet: pick area, date, target_plant_count, optional assignee | `admin_data` | — |

### Seeds (sub-phase 3-12)

| File | Responsibility | Role gate | Slice |
|------|----------------|-----------|-------|
| `src/screens/seeds/SeedsListScreen.tsx` | Master list; low-stock badges | `admin_data` (Taman Aktif), `top_management` | `seeds` |
| `src/screens/seeds/SeedDetailScreen.tsx` | Ledger view per seed | same | `seeds` |
| `src/screens/seeds/AddTransactionScreen.tsx` | Record purchase / distribution / adjustment | same | `seeds` |

---

## Redux Slices (new)

| Slice | State | Thunks |
|-------|-------|--------|
| `monitoringV2` | `{ snapshot, visibleLayers, selectedUserId, selectedAreaId, clusterZoomThreshold }` | `fetchSnapshot`, `applyPatch` (WS), `toggleLayer` |
| `plants` | `{ speciesCatalog[], areaPlantsByArea, notableByArea, areaStatusById }` | `fetchSpeciesCatalog`, `fetchAreaPlants`, `upsertAreaPlants` |
| `pruningRequests` | `{ mine[], queue, byId, filters }` | `submit`, `fetchMine`, `fetchQueue`, `review`, `convertToTask` |
| `seeds` | `{ seeds[], transactionsBySeed }` | `fetchSeeds`, `fetchTransactions`, `recordTransaction` |

Existing `tasks` slice extended with `lineageById`, `partialComplete`, `resume`.

---

## Offline Queue Scaffolds (3-7, 3-10)

Full offline polish is **deferred to Phase 4** per [ADR-019](../../architecture/decisions/ADR-019-offline-connectivity-model.md). This phase scaffolds the queue items so Phase 4 can polish retry/conflict logic:

| Queue action | Triggered by | Payload |
|--------------|--------------|---------|
| `activity.submit` | `PruningTaskForm` submit when offline | `{ task_id, custom_fields, plant_items, photos[] }` |
| `activity.partial` | Partial-complete sheet submit when offline | `{ task_id, completed_count, plant_items, resume_tomorrow }` |
| `pruning_request.submit` | Kecamatan submit when offline | `{ address, expected_date, photos[], gps }` |

Scaffolds live in `src/services/sync/offlineQueue.ts` but are wired with a simple FIFO flush on connectivity restore. Retry / conflict / duplicate-guard logic is Phase 4 scope.

---

## Navigation Gates (`src/navigation/RootNavigator.tsx`)

| Role | Entry route | Visible tabs |
|------|-------------|--------------|
| `satgas` | `HomeScreen` | Home · Tasks · Map (read-only area) · Profile |
| `linmas` | `HomeScreen` | Home · Map · Profile |
| `korlap` | `HomeScreen` | Home · Tasks · Map · Profile |
| `admin_data` | `HomeScreen` | Home · Tasks · Map · Requests (review) · Seeds (if Taman Aktif) · Profile |
| `kepala_rayon` | `MapDashboardScreen` | Map · Tasks · Profile |
| `top_management` | `MapDashboardScreen` | Map · Overview · Profile |
| `staff_kecamatan` | `SubmitScreen` | Submit · My Requests · Profile |

`staff_kecamatan` has a **dedicated minimal shell** — no bottom tab bar with monitoring. Navigation guard in `RootNavigator` redirects any attempt to reach `/monitoring/*` routes.

---

## WebSocket Integration

Subscribe on login via existing `WebSocketService`:

```ts
ws.on('status:v2',                 patch => dispatch(monitoringV2.applyStatusPatch(patch)));
ws.on('cluster:update',            patch => dispatch(monitoringV2.applyClusterPatch(patch)));
ws.on('inventory:updated',         patch => dispatch(plants.applyInventoryPatch(patch)));
ws.on('request:status-changed',    patch => dispatch(pruningRequests.applyStatusPatch(patch)));
ws.on('area:plant-status-changed', patch => dispatch(plants.applyAreaStatusPatch(patch)));
```

React components react via selectors; map re-renders only dirty cluster/polygon children.

---

## Feature Flag

`fe/mobile/src/config/featureFlags.ts`:

```ts
export const featureFlags = {
  clusterMarkersV2: { default: false, remoteOverrideKey: 'phase3.cluster_v2' },
  phase3Enabled:    { default: false, remoteOverrideKey: 'phase3.enabled' },
};
```

Rollout: enable `phase3Enabled` for pilot rayon (Selatan) first; `clusterMarkersV2` stays off until 3-5 regression suite passes. Lint rule prevents re-enabling `tracksViewChanges={true}` regardless of flag state.

---

## Testing (3-7 → 3-10 → 3-12 → 3-14)

| Test file | Scope |
|-----------|-------|
| `__tests__/components/PruningTaskForm.test.tsx` | dynamic fields render; species autocomplete; partial submit dispatches `activity.partial` queue action |
| `__tests__/components/ClusterMarker.test.tsx` | `tracksViewChanges={false}`; key stability across cluster-count changes |
| `__tests__/screens/ClusterStability.test.tsx` | 500 mock users; zoom in/out; assert no bitmap redraw storm (spy on `_requestLayout`) |
| `__tests__/screens/SubmitScreen.test.tsx` | Photo picker; GPS capture; offline queue fallback |
| `__tests__/screens/ReviewQueueScreen.test.tsx` | Approve / reject / convert flows; capacity chip visible |
| `__tests__/slices/pruningRequests.test.ts` | State machine transitions applied from WS patches |

Coverage target: maintain ≥ 80 % overall; ≥ 85 % on new files.

---

**Last Updated:** 2026-04-25
