# Phase 3: Plants Management, Monitoring Rebuild & Public Intake

**Date:** April 24, 2026
**Status:** Not Started
**Priority:** High — Monitoring rebuild unblocks production-scale operation; plants + public intake are client-approved flagship features for this phase
**Duration:** ~63 developer-days estimated (4 weeks wall-clock with parallel backend/web/mobile developers)
**Depends On:** Phase 2E (Complete)
**Related ADRs:** [ADR-005](../../architecture/decisions/ADR-005-gps-boundary-tolerance.md), [ADR-009](../../architecture/decisions/ADR-009-phase2c-role-system-overhaul.md), [ADR-010](../../architecture/decisions/ADR-010-phase2c-terminology-cleanup.md), [ADR-011](../../architecture/decisions/ADR-011-phase2d-monitoring-status-model.md) (superseded by ADR-029), [ADR-013](../../architecture/decisions/ADR-013-multi-area-korlap-assignments.md), [ADR-016](../../architecture/decisions/ADR-016-redis-websocket-scaling.md) (promoted from Phase 4), [ADR-029](../../architecture/decisions/ADR-029-monitoring-v2-redis.md), [ADR-030](../../architecture/decisions/ADR-030-area-aggregate-plant-inventory.md), [ADR-031](../../architecture/decisions/ADR-031-task-typing-custom-fields.md), [ADR-032](../../architecture/decisions/ADR-032-admin-data-pruning-disposition.md), [ADR-033](../../architecture/decisions/ADR-033-staff-kecamatan-role.md), [ADR-034](../../architecture/decisions/ADR-034-pruning-cycle-prediction.md), [ADR-035](../../architecture/decisions/ADR-035-service-capacity-model.md), ADR-036 (design-token single-source) *pending*, ADR-037 (web PWA adoption) *pending*
**Platform design foundation:** [specs/ui-ux/design-tokens.md](../../ui-ux/design-tokens.md) — Phase 3 is the adoption vehicle.

---

## Overview

Phase 3 delivers three interlocking streams of work, all triggered by client feedback in April 2026 after a production walk-through with the mayor's office:

1. **Monitoring v2 (full rewrite).** The Phase 2D monitoring implementation is not production-scale: `StatusCalculatorService.onLocationPing` issues 6+ database queries per ping (saturates the 15-connection pool at 500 workers); only the last location in a batch triggers a status calc; `location_logs` is missing every composite index except the PK; and `AREA_STAFFING_CHANGED` emits on every GPS flap without debounce. This phase decouples ingest from projection via Redis Streams, adds a Socket.IO Redis adapter for horizontal scale, installs a staffing debouncer + stale-status sweep cron, and rebuilds map UX with supercluster everywhere — all while **preserving** the Apr 24 marker/trail bug fixes (`tracksViewChanges={false}`, `LabelMode` enum in marker `key`, `requestAnimationFrame` mount guard, `useFocusEffect`-driven boundary re-fetch).

2. **Plants management + task typing.** The mayor asked DLH to stop running pruning reactively. Phase 3 introduces `plant_species` (131 rows from the CSV historical log), `area_plants` aggregate inventory per area×species with `last_pruned_at` / `next_due_at` / `status` (ok / due / overdue), optional `notable_plants` for heritage records, a `task_type` enum + JSONB `custom_fields` schema registry, partial-complete and resume-tomorrow parent/child task lineage, and a deterministic species×area_type due-date forecaster ([ADR-034](../../architecture/decisions/ADR-034-pruning-cycle-prediction.md)). Top-management dashboards surface overdue areas; the 5,008-row CSV is backfilled into `activities` + `activity_plant_items`.

3. **Public intake + capacity + seed ledger.** A new external role `staff_kecamatan` lets sub-district staff submit pruning requests that currently arrive as paper letters. `admin_data` (already rayon-scoped via [ADR-013](../../architecture/decisions/ADR-013-multi-area-korlap-assignments.md)) gains disposition authority over these requests ([ADR-032](../../architecture/decisions/ADR-032-admin-data-pruning-disposition.md)) — a narrow capability extension, **not** a new role. Converted requests book `service_capacity` (rayon × ISO-week × service_type; reusable for future DLH services) and link back to the originating request so kecamatan can see completion photos. Plant-seed inventory gets a unified `plant_seeds` + `seed_transactions` ledger usable by `admin_data` at Rayon Taman Aktif and `top_management`.

### Requirements Summary

| # | Requirement | Source | Sub-Phase |
|---|-------------|--------|-----------|
| 1 | Rewrite monitoring pipeline: Redis Streams projector, Socket.IO Redis adapter, debounced staffing events, stale-status sweep, eager-loaded `onLocationPing` | Client (production-scale bugs) | 3-3 |
| 2 | Add missing `location_logs` indexes; add `user_tracking_status (area_id, updated_at DESC)` and `(is_within_area, area_id)` | Evidence (`be/src/modules/monitoring/services/status-calculator.service.ts:186-263`) | 3-3 |
| 3 | Web monitoring: supercluster, incremental WS patches, virtualized worker list, hierarchy toggles (rayon/area/worker), plant + overdue overlays | Client | 3-4 |
| 4 | Mobile monitoring: cluster markers (parallel `ClusterMarker`, keep `UserMarker` intact behind feature flag), overlay toggle sheet, area fill by plant status | Client (preserve Apr 24 fixes) | 3-5 |
| 5 | `plant_species` catalog + `area_plants` aggregate inventory + optional `notable_plants` | Client (mayor directive) | 3-2, 3-8 |
| 6 | Task typing (`task_type` enum + JSONB `custom_fields` schema registry) + parent/child lineage + partial-complete (`target_plant_count` / `completed_plant_count`) + species line items (`activity_plant_items`) | Client | 3-6 |
| 7 | Pruning task mobile form with 131-species autocomplete, resume-tomorrow CTA | Client | 3-7 |
| 8 | Deterministic species × area_type due-date forecast with manual override; overdue alerts to `top_management` | Client | 3-8 |
| 9 | `staff_kecamatan` role + `pruning_requests` entity + submission/review/convert-to-task workflow | Client | 3-9 |
| 10 | Extend `admin_data` with pruning_requests disposition (rayon-scoped) — amends [ADR-009](../../architecture/decisions/ADR-009-phase2c-role-system-overhaul.md) | Client | 3-2, 3-9 |
| 11 | Pruning request frontends: mobile submit/review; web queue/detail; kecamatan outcome visibility | Client | 3-10 |
| 12 | `service_capacity` weekly grid per rayon × `service_type` (reusable) with implicit booking on convert-to-task | Client | 3-11 |
| 13 | `plant_seeds` + `seed_transactions` unified ledger (purchase / distribution / adjustment) | Client | 3-12 |
| 14 | CSV backfill seeder (5,008 rows → `activities` + `activity_plant_items` + `area_plants`; rehost Drive photos on S3; idempotent on `reference_code`) | Client (historical data) | 3-13 |
| 15 | k6 load test harness: 500-worker, 12-second-ping, 30-minute simulation; pass criteria p95 ingest < 200 ms, broadcast < 500 ms, pool < 70 %, Redis lag < 5 s, zero missed transitions | Client | 3-14 |
| 16 | Documentation final sync: specs, COMPLETION_STATUS, root + module-level CLAUDE.md | Housekeeping | 3-15 |
| 17 | Unified design-token pipeline (`tokens.json` + generator → web CSS + mobile TS) enforced by CI; visual parity across NB primitives; canonical `#F5F0EB` canvas + hard-edge shadows | Design systems (ADR-036) | **3-0** |
| 18 | Web PWA: manifest, service worker (shell precache + SWR snapshot), install prompt, offline banner, push notifications (admins+) | Client (field supervisors on phones) + ADR-037 | **3-0** / 3-4 |
| 19 | Responsive web: mobile (<768 px) / tablet (768–1279 px) / desktop (≥1280 px) layouts on every Phase 3 page; sidebar→bottom-sheet menu; role-gated install banner for satgas/linmas/korlap | Client + accessibility | **3-0** / 3-4 / 3-10 / 3-11 |

---

## Current Codebase Facts (Verified April 24, 2026)

| Fact | Current State | Target State |
|------|---------------|--------------|
| Backend modules | 18 modules, ~130 endpoints | 22 modules (+plants, +pruning-requests, +service-capacity, +plant-seeds), ~165 endpoints |
| Backend tests | 1,264 tests (94.51 % stmts, 83.49 % branches) | >1,500 tests; ≥85 % stmts per new module |
| Database tables | 22 tables, 8 migrations | 30 tables; 8 new + 5 altered; migrations prefixed `17460000*` |
| Roles | 8 roles (ADR-009) | 9 roles: +`staff_kecamatan`. `admin_data` gains disposition over `pruning_requests` only (ADR-032) — no new `admin_rayon` |
| Mobile screens | 22 screens | 27 screens (+monitoring v2 overlays, +PruningTaskForm, +SubmitPruningRequest, +MyRequests, +ReviewQueue, +Seeds) |
| Web pages | 21 pages | 28 pages (+plants/, +pruning-requests/, +seeds/, +rayons/[id]/capacity/) |
| Monitoring pipeline | 6+ DB queries per ping; latest-in-batch only; no debounce; no stale sweep; in-process Socket.IO | Redis Streams consumer group + projector; per-ping eager-load once; debounced staffing events; 5-min stale sweep cron; Redis Socket.IO adapter |
| `location_logs` indexes | PK only | +`(user_id, logged_at DESC)`, `(shift_id, logged_at)`, `(user_id, shift_id, logged_at)` |
| Infrastructure | PostgreSQL + Adminer + LocalStack S3 | +Redis 7 (docker-compose and `REDIS_URL` env) |
| Mobile marker rendering | Per-user `UserMarker`, Apr 24 fixes in place | Parallel `ClusterMarker` + `UserMarker`, A/B feature flag; lint rule forbids re-enabling `tracksViewChanges=true` |
| Tasks | No `task_type`, no `parent_task_id`, no partial-completion columns, 8 statuses | +`task_type`, +`custom_fields` JSONB, +`parent_task_id`, +`target_plant_count`, +`completed_plant_count`. Status simplification (8→4) remains a **Phase 4 backlog item** |
| Activities | No custom_fields, no plant line items, no reference_code | +`custom_fields` JSONB, +`activity_plant_items` relation, +`reference_code` (preserves CSV IDs), +`photo_before_url` / `photo_after_url`, +`pruning_request_id` |
| Public intake | Nothing (paper letters) | Full submit → review → convert → outcome loop |

---

## Role Access Matrix

**Legend:** `Y` = full access; `Y (scope)` = scoped; `-` = no access; `Ext` = capability extension of existing role per ADR-032.

| Feature | satgas | linmas | korlap | admin_data | kepala_rayon | top_management | admin_system | superadmin | staff_kecamatan |
|---------|--------|--------|--------|------------|--------------|----------------|--------------|------------|-----------------|
| Monitoring map v2 (view) | - | - | Y (own area) | Y (own rayon) | Y (own rayon) | Y (all) | Y (all) | Y (all) | - |
| Cluster/overlay toggles | - | - | Y | Y | Y | Y | Y | Y | - |
| Plant overlay + overdue colors | - | - | Y (own area) | Y (own rayon) | Y (own rayon) | Y (all) | Y (all) | Y (all) | - |
| Plant species catalog (read) | Y | Y | Y | Y | Y | Y | Y | Y | Y (own submissions) |
| Plant species catalog (write) | - | - | - | - | - | - | Y | Y | - |
| Area plants inventory (view) | Y (own area) | Y (own area) | Y (own area) | Y (own rayon) | Y (own rayon) | Y (all) | Y (all) | Y (all) | - |
| Area plants inventory (bulk upsert) | - | - | - | Y (own rayon) | Y (own rayon) | - | Y | Y | - |
| Notable plants CRUD | - | - | Y (own area) | Y (own rayon) | Y (own rayon) | Y (all) | Y | Y | - |
| Create typed task (pruning/watering/planting) | - | - | Y (own area) | Y (own rayon) | Y (own rayon) | - | Y | Y | - |
| Pruning task partial-complete / resume | Y (assigned) | - | Y (own area) | - | - | - | - | - | - |
| Task lineage tree | - | - | Y (own area) | Y (own rayon) | Y (own rayon) | Y | Y | Y | - |
| Submit pruning request | - | - | - | - | - | - | - | - | Y |
| List own pruning requests | - | - | - | - | - | - | - | - | Y (own submissions) |
| Pruning request review queue | - | - | - | Y (own rayon, Ext per ADR-032) | - | Y (read-only all) | Y | Y | - |
| Approve / reject / convert-to-task | - | - | - | Y (own rayon, Ext) | - | - | Y | Y | - |
| See outcome (task + activities + photos) | - | - | Y (if assigned) | Y (own rayon) | Y (own rayon) | Y | Y | Y | Y (own submissions) |
| Service capacity (view) | - | - | Y (own rayon) | Y (own rayon) | Y (own rayon) | Y (all) | Y | Y | - |
| Service capacity (edit) | - | - | - | Y (own rayon) | - | Y (all) | Y | Y | - |
| Plant seed inventory (view) | - | - | - | Y (Taman Aktif) | - | Y | Y | Y | - |
| Plant seed transactions (record) | - | - | - | Y (Taman Aktif) | - | Y | Y | Y | - |
| Overdue alerts dashboard | - | - | - | Y (own rayon digest) | Y (own rayon digest) | Y (all) | Y | Y | - |

---

## Monitoring Hierarchy (v2)

Unchanged from Phase 2D at the org-model level; the pipeline underneath changes radically. `staff_kecamatan` is outside the monitoring hierarchy entirely.

```
top_management / admin_system / superadmin
    |-- All 7 rayons
    |       |-- All areas (polygon + plant overlay)
    |       |       |-- All workers (supercluster rendering)

kepala_rayon
    |-- OWN rayon
            |-- All areas within own rayon
                    |-- All korlap + satgas/linmas + activities

admin_data (extended per ADR-032)
    |-- OWN rayon (rayon_id column)
            |-- monitoring read + pruning_request disposition

korlap
    |-- OWN area(s) (ADR-013 multi-area)
            |-- Subordinate satgas/linmas + tasks

staff_kecamatan  (out of hierarchy)
    |-- Own pruning_requests only
            |-- Outcome visibility (converted task + activities)
```

---

## Implementation Phases

| Sub-Phase | Name | Est. days | Depends on | Token-adopt |
|-----------|------|-----------|-----------|:----------:|
| **3-0** | **Design-token foundation + PWA shell** (`tokens.json` + generator + CI; NB primitives migrated; web PWA manifest + service worker + install banner; canonical canvas + hard-edge shadows across both platforms) | 3 | 3-1 | **ships** |
| **3-1** | Spec deferral (Phase 3→4, Phase 4→5), ADRs 029–037, CLAUDE.md sync | 2 | — | — |
| **3-2** | Schema + role extension (new tables, `activities`/`tasks` additions, `staff_kecamatan`, `admin_data` policy extension) | 4 | 3-1 | — |
| **3-3** | Monitoring v2 backend: Redis, Streams, projector, debouncer, stale sweep, index migrations, eager loads | 7 | 3-2 | — |
| **3-4** | Monitoring v2 web: supercluster, incremental WS, virtualized list, hierarchy toggles, overlays, **responsive layout**, **PWA shell consumed** | 6 | 3-3, **3-0** | **adopts** |
| **3-5** | Monitoring v2 mobile: cluster markers (preserving Apr 24 fixes), overlay toggles, area fills | 5 | 3-3, **3-0** | **adopts** |
| **3-6** | Task typing + custom fields + parent/child + partial-complete API | 4 | 3-2 | — |
| **3-7** | Pruning task UX (mobile form + resume flow; web assignment) | 5 | 3-6, **3-0** | **adopts** |
| **3-8** | Plant due-date forecast + overdue alerts to `top_management` | 3 | 3-6 | — |
| **3-9** | Pruning-requests module (backend entity + workflow + extended `admin_data` guards + notifications) | 4 | 3-2 | — |
| **3-10** | Pruning-requests frontends (mobile kecamatan + review; web queues + detail; **PWA push for new requests**) | 5 | 3-9, 3-6, **3-0** | **adopts** |
| **3-11** | Service capacity calendar (backend + web **with responsive week grid** + mobile lookup) | 4 | 3-9, **3-0** | **adopts** |
| **3-12** | Plant-seed inventory (backend + mobile + web) | 3 | 3-2, **3-0** | **adopts** |
| **3-13** | CSV backfill seeder (5,008 rows, photo rehosting, idempotent) | 3 | 3-6 | — |
| **3-14** | Load test (k6 500-worker simulation) + regression fixes | 3 | 3-3…3-8 | — |
| **3-15** | Documentation final sync (specs, COMPLETION_STATUS, all CLAUDE.md) | 2 | all | — |

**Total:** 63 dev-days single-threaded.

`3-0` runs in parallel with `3-1` / `3-2` — it touches the frontend toolchain only, so it never blocks backend schema or role-enum work.

### Parallelization Diagram

```
Week 1:  3-1 (ADR + spec deferral) ─── 3-2 (schema + roles) ───────────────┐
                                                                           │
Week 2:  3-3 (monitoring backend) ─────────────────────────────────┐       │
         3-6 (task typing API)     ─────────────────┐              │       │
         3-9 (pruning_requests BE) ─────────┐       │              │       │
         3-12 (seed ledger)        ─────────┤       │              │       │
                                            │       │              │       │
Week 3:  3-4 (web monitoring)  ←────────────┼───── 3-3             │       │
         3-5 (mobile monitoring)←────────── 3-3                    │       │
         3-7 (pruning task UX)  ←────────── 3-6                    │       │
         3-8 (due-date forecast)←────────── 3-6                    │       │
         3-10 (pruning FE)      ←────────── 3-9, 3-6               │       │
         3-11 (capacity cal.)   ←────────── 3-9                    │       │
         3-13 (CSV backfill)    ←────────── 3-6                    │       │
                                                                   │       │
Week 4:  3-14 (k6 load test) ←──────────────── 3-3…3-8             │       │
         3-15 (doc sync) ←────────────────────── all ──────────────┴───────┘
```

### Sub-Phase Detail

#### 3-0: Design-token foundation + PWA shell (3 days)

Full spec: [specs/ui-ux/design-tokens.md](../../ui-ux/design-tokens.md). Summary of deliverables:

| Task | Scope | Key Files |
|------|-------|-----------|
| `tokens.json` source of truth | Layer 1 registry: colors, borders, radii, spacing, shadows, type scale, motion | `specs/ui-ux/tokens.json`, `specs/ui-ux/tokens.schema.json` |
| Generator script | Reads `tokens.json`, emits `generated/tokens.css` (web) + `generated/tokens.ts` (mobile); 100-line hand-rolled TS | `scripts/build-tokens.ts`, `npm run tokens:build` |
| CI verifier | Validates schema, re-runs generator, diffs output against committed generated files; fails PR on drift | `.github/workflows/tokens.yml`, `npm run tokens:verify` |
| Web consumer wiring | `fe/web/src/app/globals.css` imports `generated/tokens.css`; Tailwind config reads CSS vars | `globals.css`, `tailwind.config.ts` |
| Mobile consumer wiring | `fe/mobile/src/constants/nbTokens.ts` re-exports from `generated/tokens.ts` | `nbTokens.ts` |
| Shadow rewrite | Every NB primitive switches to hard-edge (`shadowRadius: 0` mobile, `0 blur` web); kills the blurred-shadow drift | `NBButton`, `NBCard`, `NBBadge`, `NBTextInput`, web `button`/`card`/`badge`/`input` |
| Canvas color swap | App background becomes `#F5F0EB` on both platforms (supersedes pastel yellow as page bg) | `RootLayout`, `globals.css`, mobile root screen styles |
| PWA manifest + icons | `manifest.webmanifest`, 192/512/maskable/apple-touch icons | `fe/web/public/manifest.webmanifest`, `fe/web/public/icons/` |
| Service worker | Shell precache + SWR for `/monitoring` snapshot + network-first for detail pages; write actions network-only | `fe/web/src/sw/sw.ts`, registered via `next-pwa` or hand-rolled |
| Install banner | NB-styled install prompt on login + `/monitoring`; `localStorage` 14-day suppression; iOS Safari fallback page | `components/pwa/InstallBanner.tsx`, `app/install-help/page.tsx` |
| Offline shell + banner | `navigator.onLine === false` → yellow banner + disabled write CTAs | `components/pwa/OfflineBanner.tsx`, `hooks/useOnlineStatus.ts` |
| Push notifications | FCM registration for `admin_data`+; mirror mobile notification types | `services/pushNotifications.ts`, `app/api/push/register/route.ts` |
| Visual regression snapshots | Playwright baseline before migration; re-capture after to prove no regressions | `e2e/visual-regression.spec.ts` |
| ADR-036 + ADR-037 | Token single-source decision; web PWA adoption decision | `specs/architecture/decisions/` |

**Deliverables:** `tokens.json` live; both platforms consume generated files; NB primitives visually identical with hard-edge shadows; PWA installable; offline shell degraded mode works; `npm run tokens:verify` green in CI.

**Rollout ordering inside 3-0:**

1. Day 1 — write `tokens.json` + generator + CI; commit generated files; both apps continue to look identical (generator matches current values exactly).
2. Day 2 — migrate NB primitives to generated tokens; swap shadow blur → 0; swap canvas → `#F5F0EB`. Visual-regression diffs reviewed as intentional.
3. Day 3 — PWA manifest + service worker + install banner + offline shell + push registration.

**Unblocks:** 3-4, 3-5, 3-7, 3-10, 3-11, 3-12 — all of which ship on the new token system and (on web) inside the PWA shell.

#### 3-1: Spec deferral + ADRs + CLAUDE.md sync (2 days)

| Task | Scope |
|------|-------|
| Rename `phase-3-polishing/` → `phase-4-production-readiness/`; `phase-4-finishing/` → `phase-5-finishing-ios/` | git-tracked moves |
| Update cross-references in renamed folders | content sync only |
| Write ADR-029…035 (see spec ADRs index) | 7 ADRs |
| Sync `specs/README.md`, `specs/phases/README.md`, `specs/phases/DEPENDENCY_MATRIX.md`, `specs/COMPLETION_STATUS.md`, root `CLAUDE.md` | housekeeping |

**Deliverables:** 7 ADRs, renamed folders, updated phase index.

#### 3-2: Schema + role extension (4 days)

| Task | Scope | Key Files |
|------|-------|-----------|
| Migration `17460000000000-Phase3Schema.ts` | new tables + altered tables + role-enum extension | `be/src/database/migrations/` |
| Seed `plant_species` (131 rows) | dedupe CSV column 6 | `be/src/database/seeds/seed-plant-species.ts` |
| Seed `monitoring_configs` additions | staffing_debounce_seconds, stale_status_sweep_cron, cluster_zoom_threshold, redis_stream_max_len | `seed-monitoring-configs.ts` |
| Add `staff_kecamatan` to `UserRole` enum + `constants/role-groups.ts` | new group `PRUNING_REQUEST_REVIEWERS = [admin_data]` | `be/src/modules/users/enums/role.enum.ts`, `constants/role-groups.ts` |
| Sweep every `@Roles(...)` decorator | verify `staff_kecamatan` denied where appropriate | `be/src/modules/**/*.controller.ts` |

**Deliverables:** 8 new tables, 5 altered tables, enum extension, `PRUNING_REQUEST_REVIEWERS` permission group.

#### 3-3: Monitoring v2 backend (7 days)

| Task | Scope | Key Files |
|------|-------|-----------|
| Redis service + health check + fallback to in-process pub/sub | `REDIS_URL` env, connection-pool with graceful shutdown | `be/src/common/services/redis.service.ts` |
| Socket.IO Redis adapter wiring | `@socket.io/redis-adapter` on `EventsGateway` | `be/src/gateways/events.gateway.ts` |
| Redis Streams location→status pipeline | producer on `onLocationPing`, consumer group `monitoring-projector` | new `StatusProjectorService` |
| `StatusProjectorService` | reads stream, eager-loads user context once, writes `user_tracking_status`, emits events | new service |
| `StaffingDebouncerService` | collapses bursts within `STAFFING_DEBOUNCE_SECONDS` (default 30) | new service |
| `StaleStatusSweeperService` | `@Cron('*/5 * * * *')`, flips ACTIVE without recent ping → MISSING | new service |
| Rewrite `onLocationPing` | single user-context eager-load; queue to Redis stream instead of 6+ DB queries | `be/src/modules/monitoring/services/status-calculator.service.ts:186-263` |
| Fix batch-ingest bug | iterate batch (or sample), not just latest | `be/src/modules/location/location.service.ts:92-103` |
| Index migrations | `location_logs` + `user_tracking_status` (see database.md) | `Phase3Schema.ts` |
| `GET /monitoring/snapshot` unified payload | replaces multiple round-trips; keyed React Query cache | `monitoring.controller.ts` |

**Deliverables:** Redis + Socket.IO adapter + Streams projector + debouncer + sweeper + rewritten `onLocationPing` + snapshot endpoint + all indexes.

#### 3-4: Monitoring v2 web (6 days)

| Task | Scope | Key Files |
|------|-------|-----------|
| Supercluster layer | Mapbox GL JS + `supercluster` npm | `fe/web/src/components/monitoring/ClusterLayer.tsx` |
| Incremental WS patch handling | React Query cache key `monitoring:snapshot:<scope>:<id>`; apply patches on message | `fe/web/src/app/(dashboard)/monitoring/page.tsx:100-216` |
| Virtualized worker list | `@tanstack/react-virtual` | `WorkerListVirtual.tsx` |
| Hierarchy filter panel | rayon / area / worker cascading toggles | `HierarchyFilterPanel.tsx` |
| Plant overlay + overdue color layer | green/yellow/red area fill by `area_plants.status` | `PlantOverlayLayer.tsx`, `AreaStatusOverlay.tsx` |
| Area detail drawer | shift info + activities + plants summary | `AreaDetailDrawer.tsx` |

**Deliverables:** Supercluster rendering, incremental WS, virtualized list, role-aware sidebar covering 9 roles.

#### 3-5: Monitoring v2 mobile (5 days)

| Task | Scope | Key Files |
|------|-------|-----------|
| `ClusterMarker` parallel component | leaves existing `UserMarker` intact | `fe/mobile/src/components/monitoring/ClusterMarker.tsx` |
| Cluster-vs-markers switch by zoom | preserves `tracksViewChanges={false}` + `LabelMode` enum in key | `ClusteredUserMarkers.tsx` |
| A/B feature flag | `featureFlags.clusterMarkersV2` | `fe/mobile/src/config/featureFlags.ts` |
| Lint rule | forbid re-enabling `tracksViewChanges={true}` anywhere in `components/monitoring/` | `.eslintrc` custom rule |
| Overlay toggle sheet | NB bottom sheet, workers/plants/overdue toggles | `MonitoringToggleSheet.tsx` |
| Area status fill | color by `area_plants.status` | `AreaStatusOverlay.tsx` |
| Preserve `LocationTrail` `requestAnimationFrame` mount guard | reference pattern; do not modify file | `components/monitoring/LocationTrail.tsx` |

**Deliverables:** Parallel cluster path behind flag, overlay sheet, area status fill, preserved Apr 24 fixes.

#### 3-6: Task typing + partial-complete API (4 days)

| Task | Scope |
|------|-------|
| Extend `Task` entity | `task_type`, `custom_fields`, `parent_task_id`, `target_plant_count`, `completed_plant_count` |
| `TaskTypeRegistry` service | per-type Zod schema for `custom_fields` validation |
| `POST /tasks` extensions | accept `task_type`, `custom_fields`, `target_plant_count` |
| `POST /tasks/:id/partial-complete` | body includes progress + plant_items; spawns child if `completed_plant_count < target_plant_count` |
| `POST /tasks/:id/resume` | creates child task linked via `parent_task_id` |
| `GET /tasks/:id/lineage` | tree of parent/children |
| Extend `Activity` entity | `custom_fields`, `reference_code`, `pruning_request_id`, `photo_before_url`, `photo_after_url` |
| `activity_plant_items` relation | species × count line items |

**Deliverables:** Typed tasks API, activity extensions, `TaskTypeRegistry`.

#### 3-7: Pruning task UX (5 days)

| Task | Scope |
|------|-------|
| `PruningTaskForm` component | species autocomplete (131 entries), quantity, maintenance type (PC/PM/PB), partial-complete action |
| Task detail "Lanjutkan Besok" CTA | calls `/tasks/:id/resume` |
| Web task create: dynamic form per `task_type` | species multi-select with quantities |
| Mobile offline queue scaffold | `activity.submit`, `activity.partial` (full offline polish deferred to Phase 4 / ADR-019) |

#### 3-8: Due-date forecast + overdue alerts (3 days)

| Task | Scope |
|------|-------|
| `PlantDueDateService` | species × area_type lookup; manual override column |
| `@Cron('0 2 * * *')` `PlantDueDateRecalculator` | daily recomputation of `area_plants.next_due_at` / `status` |
| Top-management alerts digest | daily email/FCM on overdue areas |

#### 3-9: Pruning-requests backend (4 days)

| Task | Scope |
|------|-------|
| `PruningRequestService` | submit / list / review / convert / outcome |
| Guard extension for `admin_data` via `PRUNING_REQUEST_REVIEWERS` | new role-group constant |
| Rayon scoping via `users.rayon_id` | reject if request rayon ≠ reviewer rayon |
| Notifications on status change | FCM to submitter; toast on web |

#### 3-10: Pruning-requests frontends (5 days)

| Task | Scope |
|------|-------|
| Mobile `SubmitScreen` (kecamatan) | GPS capture, photo upload, expected_date |
| Mobile `MyRequestsScreen` + `RequestDetailScreen` | outcome visibility with task + activity photos |
| Mobile `ReviewQueueScreen` (admin_data) | approve/reject/convert-to-task |
| Web `/pruning-requests/` queue + `[id]/` detail | filter by status, rayon (for top_management read-only) |

#### 3-11: Service capacity calendar (4 days)

| Task | Scope |
|------|-------|
| `CapacityService` | weekly grid per rayon × ISO-week × service_type; implicit booking on convert-to-task |
| `GET/PUT /rayons/:id/capacity?service_type=&year=&from_week=&to_week=` | admin_data (own rayon) / top_management |
| `POST /rayons/:id/capacity/book` | manual adjustment |
| Web capacity calendar page | week grid with editable capacity + booked bar |
| Mobile read-only view in `ReviewQueueScreen` | shows available slot before convert |

#### 3-12: Plant-seed inventory (3 days)

Unified `plant_seeds` + `seed_transactions` ledger. CRUD on web + mobile for `admin_data` at Rayon Taman Aktif and `top_management`.

#### 3-13: CSV backfill seeder (3 days)

One-off importer. Idempotent on `activities.reference_code`. Rehosts Google Drive photos to S3 via background job. Discards blank columns 18/19 and the `#VALUE!` header in column 22.

#### 3-14: Load test + regression fixes (3 days)

k6 harness simulating 500 workers pinging every 12 s for 30 min. Pass criteria:
- p95 ingest < 200 ms
- p95 status broadcast < 500 ms
- Postgres pool utilization < 70 %
- Redis stream consumer lag < 5 s
- Zero missed status transitions (sampled from event log)

#### 3-15: Documentation final sync (2 days)

Update `specs/COMPLETION_STATUS.md`, all phase STATUS files, and every module-level `CLAUDE.md` touched by this phase.

---

## Risk Assessment

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|-----------|
| Amending ADR-009 surprises stakeholders | Medium | Medium | ADR-032 documents scope narrowly (pruning_requests only, rayon-scoped); no overtime or user-mgmt rights added |
| Token migration regresses visual identity on Phase 2 screens still on hand-rolled styles | Medium | Low | 3-0 touches only NB primitives + canvas bg; untouched screens keep current look until Phase 4 sweep. Visual-regression Playwright run at end of 3-0. |
| PWA service-worker caching confuses field users (stale monitoring data feels broken) | Medium | Medium | SWR with explicit 30 s TTL + always-visible banner when serving cached data; never cache write endpoints; `Skip waiting` on new SW version so deploys are instant. |
| iOS Safari PWA install story is awkward | High | Low | Ship `/install-help` page with screenshots; accept that iOS PWAs have second-class install UX — fallback to Add-to-Home-Screen instructions is acceptable. |
| Unknown CSV acronyms (GT / PT / PS / PK / PD) | Medium | Low | Store raw codes + `display_label` lookup so labels change without migration; confirm with client in 3-2 |
| 131-species taxonomy is messy | Medium | Low | Keep raw `name_id`; build clean lookup iteratively; do not block on perfect taxonomy |
| Mobile cluster regression re-introduces Apr 24 marker jank | Medium | High | Keep `UserMarker` intact; `ClusterMarker` is parallel; A/B feature flag + lint rule forbidding `tracksViewChanges={true}` |
| Redis outage breaks monitoring | Low | High | In-process pub/sub fallback; surface Redis state on `/health`; degraded mode is explicit |
| k6 reveals unknown bottlenecks | Medium | Medium | 3-14 reserves 3 days with regression-fix budget |
| `staff_kecamatan` breaks existing `@Roles(...)` guards | Medium | Medium | Systematic grep in 3-2; role-matrix integration test covering every endpoint |
| ADR-009 task-status debt (8 vs 4) lingers | High | Low | Explicitly deferred; logged in Phase 4 backlog |

---

## Open Questions (to confirm with client early in 3-2)

- Handling-status codes GT / PT / PS / PK / PD — human-readable meanings
- Plant-seed inventory visibility: `kepala_rayon` too, or strictly `admin_data` @ Taman Aktif + `top_management`?
- Capacity calendar granularity: weekly (planned) or daily?
- Notable-plants visibility to field workers, or admin-only?
- Plant species catalog editable by `admin_data`, or `admin_system` only?

---

## What Gets Deprecated / Superseded

| Current Code | Status | Replacement |
|-------------|--------|-------------|
| In-process `EventEmitter` for Socket.IO | Replaced | Redis adapter (ADR-029) |
| `StatusCalculatorService.onLocationPing` 6+ query path | Rewritten | Eager-loaded context + Redis Streams producer |
| `location.service.ts:92-103` latest-only batch logic | Rewritten | Iterate batch (or reservoir sample) |
| Un-debounced `AREA_STAFFING_CHANGED` | Replaced | `StaffingDebouncerService` |
| ADR-011 monitoring status model (single-source) | Superseded | ADR-029 (event-sourced, decoupled projector) |
| Phase 4 Redis adoption (ADR-016) | Promoted earlier | Installed in this phase; Phase 4 inherits |
| `report` entity mentions in legacy docs | Already dropped in ADR-010 | No change |

---

## Related Documents

- [Backend Requirements](./backend.md)
- [Database Schema](./database.md)
- [Mobile Requirements](./mobile.md)
- [Web Requirements](./web.md)
- [Infrastructure](./infrastructure.md)
- [Testing Plan](./testing.md)
- [UI/UX Design](./ui-ux.md)
- [Manual Testing Checklist](./manual-testing.md)
- [Deployment Checklist](./status_deployment_checklist.md)
- [Progress Tracker](./STATUS.md)

---

**Last Updated:** 2026-04-24
