# Phase 3: UI/UX Design

**Last Updated:** 2026-04-25
**Status:** ⏳ Not Started
**Design language:** Neo Brutalism 2.0 (WCAG 2.1 AA)
**Design foundation:** [specs/ui-ux/design-tokens.md](../../ui-ux/design-tokens.md) — **source of truth for every color, shadow, radius, and type token used below.**
**Related ADRs:** [ADR-029](../../architecture/decisions/ADR-029-monitoring-v2-redis.md), [ADR-030](../../architecture/decisions/ADR-030-area-aggregate-plant-inventory.md), [ADR-031](../../architecture/decisions/ADR-031-task-typing-custom-fields.md), ADR-036 *(tokens)*, ADR-037 *(PWA)*
**See also:** [Mobile](./mobile.md), [Web](./web.md)

---

## Design Goals

1. **One visual spine.** Mobile and web consume the same `tokens.json` — colors, shadows, radii, type. No second source.
2. **Accessibility first** — every status color is paired with a Lucide icon so color-blind users are never excluded.
3. **Respect the Apr 24 fixes** — no visual pattern is allowed if it would require re-enabling `tracksViewChanges={true}` on the mobile map.
4. **Progressive disclosure** — monitoring v2 starts minimal (workers + area fill); plant/overdue overlays are opt-in via toggle sheet.
5. **Responsive web + PWA** — every Phase 3 page works on phone / tablet / desktop; web is installable with an offline shell.

---

## Token References (NOT the source of truth)

All token **values** (hex codes, pixel sizes, shadow offsets, type scale) live in [design-tokens.md](../../ui-ux/design-tokens.md). This file references them by **name only**.

If you need a value: open `specs/ui-ux/tokens.json` (or, for humans, the registry in design-tokens.md). If you need to *add* a value: add it to `tokens.json`, then reference it here.

Tokens used in Phase 3:

| Area | Tokens |
|------|--------|
| Backgrounds | `bg.canvas`, `bg.accent.yellow`, `bg.accent.mint`, `bg.accent.green` |
| Monitoring status | `status.active` / `.idle` / `.outside` / `.missing` / `.offline` |
| Plant status | `plant.ok` / `.due` / `.overdue` |
| Request status | `request.submitted` / `.under_review` / `.approved` / `.rejected` / `.converted` / `.in_progress` / `.done` / `.cancelled` |
| Shadows | `shadow.sm` (cards), `shadow.md` (buttons), `shadow.lg` (sheets), `shadow.xl` (modals) |
| Type | `type.h1` / `.h2` / `.h3` / `.body` / `.body-sm` / `.caption` |

---

## Mobile — Monitoring Toggle Sheet (3-5)

NB bottom sheet: `border.width.thick` `border.color`, `shadow.lg` offset, `bg.accent.yellow` on active toggles.

```
┌──────────────────────────────────┐
│  ═══                             │   grabber
│                                  │
│  TAMPILKAN                       │   type.caption (uppercase)
│                                  │
│  ▣ Pekerja           ●           │   NB toggle, yellow dot = on
│  ▢ Area boundaries               │
│  ▢ Tanaman (overlay)             │
│  ▢ Tanaman terlambat             │
│  ▢ Rayon boundaries              │
│                                  │
│  [ Terapkan ]                    │   NBButton primary
└──────────────────────────────────┘
```

Toggles persist in `monitoringV2.visibleLayers`. Sheet uses `useFocusEffect` for its data load.

---

## Supercluster Markers (mobile + web, 3-4 / 3-5)

| Zoom | Rendered | Size | Fill |
|------|----------|------|------|
| < 12 | Cluster bubble w/ count | 40 px mobile, 48 px web | majority `status.*` of children |
| 12–13 | Cluster bubble w/ count | 36 px mobile, 40 px web | same |
| ≥ 14 (`cluster_zoom_threshold`) | Per-user `UserMarker` (unchanged — preserves Apr 24 fixes) | 32 px | user `status.*` |

Cluster bubble: white fill, `border.width.base` `border.color`, bold count centered (`type.h3`). Border color mirrors majority status. **No animation on re-cluster** — re-rendering via a new `key` is fine and does not regress `tracksViewChanges={false}`.

---

## Area Polygon Overlay (plants, 3-4 / 3-5)

Polygon fill opacity from [design-tokens.md §Plant status](../../ui-ux/design-tokens.md):

```
ok       → fill plant.ok      @ 0.15 opacity, stroke plant.ok
due      → fill plant.due     @ 0.25 opacity, stroke plant.due
overdue  → fill plant.overdue @ 0.35 opacity, stroke plant.overdue
```

Area center marker carries an overdue-count badge (e.g. `3 overdue`) when the plant overlay toggle is on.

---

## Mobile — Pruning Task Form (3-7)

Full-screen NB form. `bg.canvas` page, `bg.surface` card, `shadow.sm` cards, `shadow.md` sticky CTA.

```
┌──────────────────────────────────┐
│  ←  Tugas Perantingan            │
│                                  │
│  Area: Jalan Darmo Sec 1 R       │
│  Rayon: Selatan                  │
│                                  │
│  Jenis pemeliharaan              │
│  ( ) PC — Preventif              │
│  (●) PM — Manajerial             │
│  ( ) PB — Bedah                  │
│                                  │
│  Target tanaman                  │
│  ┌──────────────────────┐        │
│  │ + Tambah spesies     │        │
│  └──────────────────────┘        │
│                                  │
│  • Trembesi         x 8  [—][+]  │
│  • Sono             x 2  [—][+]  │
│                                  │
│  Selesai sebagian?               │
│  [ Lanjutkan Besok ]             │   secondary button
│  [    SELESAI      ]             │   primary (bg.accent.yellow)
└──────────────────────────────────┘
```

Species autocomplete opens a full-screen sheet with fuzzy-match over `plant_species.name_id`.
Accessibility: `accessibilityLabel="Jumlah {species} (bisa dikurangi atau ditambah)"` on every quantity control.

---

## Mobile — Pruning Request Submission (3-10, kecamatan shell)

```
┌──────────────────────────────────┐
│  Laporan Perantingan             │
│                                  │
│  Kecamatan:  Wonokromo           │
│  Alamat:     [                 ] │
│  Tanggal harapan: [ 2026-05-10 ] │
│  Perkiraan jumlah: [ 5  pohon ]  │
│                                  │
│  Lokasi GPS:                     │
│  [ ●  Ambil lokasi saya       ]  │
│  ( -7.2575, 112.7521 )           │
│                                  │
│  Foto (3–5)                      │
│  [📷] [📷] [+]                   │
│                                  │
│  Catatan                         │
│  [                              ]│
│                                  │
│  [    KIRIM PERMOHONAN       ]   │
└──────────────────────────────────┘
```

Submits to `POST /pruning-requests`. Offline → queue entry `pruning_request.submit` with a `bg.accent.yellow` banner: *"Akan dikirim saat online"*.

---

## Web — Capacity Calendar (3-11)

Desktop (≥ 1280 px): seven-column week grid, full NB treatment.

```
┌──────────────────────────────────────────────────────────┐
│  Rayon Selatan — Kapasitas Perantingan (2026)            │
│                                                          │
│  Layanan: [ Perantingan ▾ ]                              │
│                                                          │
│   Minggu 18   Minggu 19   Minggu 20   Minggu 21          │
│  ┌────────┐  ┌────────┐  ┌────────┐  ┌────────┐          │
│  │ 5 / 10 │  │ 8 / 10 │  │ 0 / 12 │  │ — / —  │          │
│  │ ▓▓▓▓░░ │  │ ▓▓▓▓▓▓ │  │ ░░░░░░ │  │        │          │
│  │ [Edit] │  │ [Edit] │  │ [Edit] │  │ [+]    │          │
│  └────────┘  └────────┘  └────────┘  └────────┘          │
└──────────────────────────────────────────────────────────┘
```

Mobile web (< 768 px): same data, vertical list with collapsible week cards; edit opens a full-screen dialog (bottom-sheet-styled).
Booked/capacity bar visible at all widths; overflow (`booked > capacity`) renders in `status.missing` red.

---

## Web — Responsive Behavior (all Phase 3 pages)

Breakpoints from [responsive-design.md](../../ui-ux/responsive-design.md):

| Width | Layout | Navigation |
|-------|--------|-----------|
| ≥ 1280 px (desktop) | Full sidebar (220 px) + multi-column content | Sidebar always visible |
| 768–1279 px (tablet) | Icon-only rail (64 px) + single-column content; map 60/40 | Rail expands on hover/click |
| < 768 px (mobile web) | Content full-width; monitoring becomes map + bottom-sheet panel | ☰ opens bottom-sheet menu (same role gating as sidebar) |

Mobile-web monitoring specifically:
- Map = full viewport
- Worker list + area details open from a **drag-up bottom sheet** (mirrors the mobile app's sheet metaphor — feels native on a phone browser)
- Hierarchy filter panel collapses into a chip row at the top that opens a filter sheet when tapped

Mobile-web banner on `/login` for `satgas` / `linmas` / `korlap`:
> "Gunakan aplikasi SEKAR untuk pengalaman terbaik di lapangan. [Pasang aplikasi →]"

---

## PWA Surfaces (3-0, consumed by 3-4 / 3-10)

Full spec: [design-tokens.md §PWA Requirements](../../ui-ux/design-tokens.md). Phase-3 UI touchpoints:

### Install banner

Appears on `/login` and `/monitoring` when `beforeinstallprompt` fires and not suppressed.

```
┌──────────────────────────────────────────────────────────┐
│  📱  Pasang SEKAR di perangkat ini                       │
│      Akses cepat ke monitoring, tanpa buka browser.      │
│                                                          │
│      [ Pasang ]     [ Nanti saja ]                       │
└──────────────────────────────────────────────────────────┘
```

Styled as an NB callout: `bg.accent.yellow` fill, `border.width.base` `border.color`, `shadow.sm` offset. "Nanti saja" suppresses for 14 days in `localStorage`.

### Offline banner

Persistent top strip when `navigator.onLine === false`:

```
┌──────────────────────────────────────────────────────────┐
│  ⚠  Mode offline — data terakhir 2 menit lalu            │
└──────────────────────────────────────────────────────────┘
```

`bg.accent.yellow` fill, `border.width.thin` bottom border. Write CTAs are visually disabled (gray-200 fill, cursor `not-allowed`) with tooltip "Butuh koneksi."

### PWA splash / standalone mode

- Background: `bg.canvas` (`#F5F0EB`)
- Theme color: `sidebar.bg` (`#1A4D2E`) — sets Android status-bar tint
- Icon: SEKAR "S" in Space Grotesk 800 on `color.primary` (`#7FBC8C`) with `border.width.extra` border + `shadow.sm` offset

### Push notification (web, admins+)

Uses the same FCM types as mobile. Notification rendered by the OS, but its click-target deep-links into the PWA:

| Type | Click-target |
|------|--------------|
| `pruning_request_submitted` | `/pruning-requests/[id]` |
| `task_overdue` | `/tasks/[id]` |
| `area_plant_overdue` | `/monitoring?focus_area=[id]&overlay=plants` |

---

## Accessibility Checklist

- [ ] Every status color paired with a Lucide icon (per design-tokens.md)
- [ ] Text contrast ≥ 4.5:1 on all status badges (verified with contrast-checker against `bg.canvas` and `bg.surface`)
- [ ] Interactive elements ≥ 44 × 44 px touch target (mobile + mobile-web)
- [ ] Focus ring visible on keyboard navigation (web) — 3 px outline, 2 px offset, `color.primary`
- [ ] Form errors announced via `aria-live="polite"`
- [ ] Supercluster bubble: `accessibilityLabel="Kelompok {count} pekerja"`; expands on tap/Enter
- [ ] Plant overlay toggle announces state change
- [ ] Pruning request timeline readable by screen reader (ordered `<ol>`, not just visual)
- [ ] PWA install banner `role="dialog"` with `aria-labelledby` / `aria-describedby`
- [ ] Offline banner `role="status"` so SR announces it on state change
- [ ] Mobile-web bottom sheets trap focus when open; Esc closes

---

## Cross-Platform Parity Notes

| Element | Mobile app | Mobile web | Desktop web | Rationale |
|---------|-----------|------------|-------------|-----------|
| Monitoring layout | Full map + sheets | Full map + drag-up sheet | 65/35 split | Input model + screen real estate |
| Pruning task form | Full-screen single-col | Full-screen single-col | Dialog for convert-flow; full page for new | Reviewer mental model |
| Species picker | Full-screen fuzzy autocomplete | Full-screen fuzzy autocomplete | Combobox dropdown | Input method |
| Capacity calendar | Read-only summary (ReviewQueue) | Vertical list w/ collapsible weeks | Week grid editor | Admin desk work on desktop |
| Kecamatan submission | Full-screen form | Full-screen form on `(kecamatan)` layout | Same, plus breadcrumb | Primary channel is mobile; web is backup |

---

## Token-Migration Checklist (per sub-phase)

Every Phase 3 sub-phase that ships UI runs this checklist at review:

- [ ] No hard-coded hex values in new code (ESLint `no-magic-colors` rule)
- [ ] No hard-coded shadow values (ESLint `no-inline-shadow` rule)
- [ ] All new components import from `@sekar/tokens` (web) / `fe/mobile/src/constants/nbTokens` (mobile)
- [ ] Visual regression snapshot captured and reviewed
- [ ] `npm run tokens:verify` green in CI
- [ ] Screenshots posted in PR description (mobile + mobile-web + tablet + desktop widths for web changes; mobile only for mobile changes)

---

**Last Updated:** 2026-04-25
